#!/bin/bash
python3 -m http.server 8000  # Or replace with your custom server command
